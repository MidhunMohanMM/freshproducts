import { Injectable } from '@angular/core';

@Injectable()
export class AppGlobals {
    readonly baseUrl: string = '68.183.89.248';
    readonly port : string = '2981';
    readonly version_no : string = 'v1';
}

//103.214.233.141:2981/v1

//68.183.89.248:2981/v1