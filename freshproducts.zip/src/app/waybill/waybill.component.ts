import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-waybill',
  templateUrl: './waybill.component.html',
  styleUrls: ['./waybill.component.css']
})
export class WaybillComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
