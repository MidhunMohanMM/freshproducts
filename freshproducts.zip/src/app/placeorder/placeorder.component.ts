import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-placeorder',
  templateUrl: './placeorder.component.html',
  styleUrls: ['./placeorder.component.css']
})
export class PlaceorderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
