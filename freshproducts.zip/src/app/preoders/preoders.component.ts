import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-preoders',
  templateUrl: './preoders.component.html',
  styleUrls: ['./preoders.component.css']
})
export class PreodersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
