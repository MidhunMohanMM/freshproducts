import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-van',
  templateUrl: './van.component.html',
  styleUrls: ['./van.component.css']
})
export class VanComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
