import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vanstocks',
  templateUrl: './vanstocks.component.html',
  styleUrls: ['./vanstocks.component.css']
})
export class VanstocksComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
